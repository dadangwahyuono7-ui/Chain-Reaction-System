import time
"""
═══════════════════════════════════════════════════════════════════════════
  STORYLINE CALCULATION ENGINE (Python Standalone Core)
  Fractal Cascade: Macro (D1-H4-H1) ➔ Micro Execution (M30-M15-M5)
  Calculates CMP Structural Levels, Trade Plan Boxes, & Sniper Signals
═══════════════════════════════════════════════════════════════════════════
"""

from typing import List, Dict, Any, Tuple
import numpy as np

def calculate_fractal_snr(candles: List[Dict[str, Any]], left_bars: int = 5, right_bars: int = 5) -> Tuple[List[float], List[float]]:
    """
    Menghitung fractal Support & Resistance (Swing Highs & Swing Lows)
    """
    if len(candles) < (left_bars + right_bars + 1):
        return [], []
    
    highs = [c["high"] for c in candles]
    lows = [c["low"] for c in candles]
    
    resistances = []
    supports = []
    
    n = len(candles)
    for i in range(left_bars, n - right_bars):
        # Swing High
        is_high = True
        curr_h = highs[i]
        for l in range(1, left_bars + 1):
            if highs[i - l] >= curr_h:
                is_high = False
                break
        if is_high:
            for r in range(1, right_bars + 1):
                if highs[i + r] >= curr_h:
                    is_high = False
                    break
        if is_high:
            resistances.append(curr_h)
            
        # Swing Low
        is_low = True
        curr_l = lows[i]
        for l in range(1, left_bars + 1):
            if lows[i - l] <= curr_l:
                is_low = False
                break
        if is_low:
            for r in range(1, right_bars + 1):
                if lows[i + r] <= curr_l:
                    is_low = False
                    break
        if is_low:
            supports.append(curr_l)
            
    return resistances, supports


def calculate_cmp_levels(rates_by_tf: Dict[str, List[Dict[str, Any]]], current_price: float) -> Dict[str, Any]:
    """
    Mengkalkulasi level CMP untuk setiap timeframe (D1, H4, H1, M30, M15, M5)
    menggunakan logika Minor SnR Breakout dari DD_Storyline_Engine_Pro.pine.
    """
    cmp_levels = {}
    barriers = {"upper": None, "lower": None}
    all_res = []
    all_sup = []
    
    tf_configs = [
        ("D1", "#38bdf8", "Daily CMP"),
        ("H4", "#a855f7", "H4 CMP"),
        ("H1", "#fbbf24", "H1 CMP"),
        ("M30", "#34d399", "M30 CMP"),
        ("M15", "#f472b6", "M15 CMP"),
        ("M5", "#60a5fa", "M5 CMP")
    ]
    
    for tf_key, color, label in tf_configs:
        candles = rates_by_tf.get(tf_key, [])
        if not candles or len(candles) < 2:
            continue
            
        sup1 = None
        res1 = None
        arah = "WAIT"
        cmp_lvl = None
        last_cmp_buy = None
        last_cmp_sell = None
        barrier_lvl = None
        
        # Iterate sequentially to build state (Minor SnR Breakout)
        for i in range(1, len(candles)):
            prev = candles[i-1]
            curr = candles[i]
            
            # Minor SnR definitions
            is_minor_sup = (prev["close"] < prev["open"]) and (curr["close"] > curr["open"])
            is_minor_res = (prev["close"] > prev["open"]) and (curr["close"] < curr["open"])
            
            if is_minor_sup:
                sup1 = min(prev["close"], prev["open"])
            if is_minor_res:
                res1 = max(prev["close"], prev["open"])
                
            c = curr["close"]
            
            if arah == "WAIT":
                if res1 is not None and c > res1:
                    arah = "BUY"
                    cmp_lvl = res1
                    last_cmp_buy = res1
                elif sup1 is not None and c < sup1:
                    arah = "SELL"
                    cmp_lvl = sup1
                    last_cmp_sell = sup1
            elif arah == "BUY":
                if sup1 is not None and c < sup1:
                    arah = "SELL"
                    barrier_lvl = last_cmp_buy
                    last_cmp_sell = sup1
                    cmp_lvl = sup1
                elif res1 is not None and c > res1:
                    last_cmp_buy = res1
                    cmp_lvl = res1
            elif arah == "SELL":
                if res1 is not None and c > res1:
                    arah = "BUY"
                    barrier_lvl = last_cmp_sell
                    last_cmp_buy = res1
                    cmp_lvl = res1
                elif sup1 is not None and c < sup1:
                    last_cmp_sell = sup1
                    cmp_lvl = sup1
        
        # Determine bias string based on arah
        if arah == "BUY":
            bias = "BUY"
        elif arah == "SELL":
            bias = "SELL"
        else:
            bias = "INSIDE_RANGE"
            
        cmp_levels[tf_key] = {
            "bias": bias,
            "cmp_value": cmp_lvl if cmp_lvl else current_price,
            "barrier_lvl": barrier_lvl,
            "color": color,
            "label": label,
            "dist_points": round(abs(current_price - (cmp_lvl if cmp_lvl else current_price)) * 100, 1)
        }
        
        if res1 is not None:
            all_res.append(res1)
        if sup1 is not None:
            all_sup.append(sup1)
        
    # Kalkulasi Barrier Terdekat (Target TP)
    upper_barriers = [r for r in all_res if r > (current_price + 0.5)]
    lower_barriers = [s for s in all_sup if s < (current_price - 0.5)]
    
    nearest_upper = min(upper_barriers) if upper_barriers else current_price + 8.0
    nearest_lower = max(lower_barriers) if lower_barriers else current_price - 8.0
    
    return {
        "levels": cmp_levels,
        "barriers": {
            "upper": round(nearest_upper, 2),
            "lower": round(nearest_lower, 2)
        }
    }


def generate_storyline_analysis(rates_by_tf: Dict[str, List[Dict[str, Any]]], current_price: float) -> Dict[str, Any]:
    """
    Analisis komprehensif Storyline Engine v10.2: Score, Regime, Sinyal Sniper, Zona
    """
    cmp_data = calculate_cmp_levels(rates_by_tf, current_price)
    levels = cmp_data["levels"]
    barriers = cmp_data["barriers"]
    
    arah_D = levels.get("D1", {}).get("bias", "WAIT")
    arah_H4 = levels.get("H4", {}).get("bias", "WAIT")
    arah_H1 = levels.get("H1", {}).get("bias", "WAIT")
    arah_M30 = levels.get("M30", {}).get("bias", "WAIT")
    arah_M15 = levels.get("M15", {}).get("bias", "WAIT")
    arah_M5 = levels.get("M5", {}).get("bias", "WAIT")
    
    m_driver = arah_M30 if arah_M30 != "WAIT" else (arah_H4 if arah_H4 != "WAIT" else "WAIT")
    
    score = 0
    if arah_D == m_driver and arah_D != "WAIT": score += 20
    if arah_H4 == m_driver and arah_H4 != "WAIT": score += 25
    if arah_H1 == m_driver and arah_H1 != "WAIT": score += 20
    if arah_M30 == m_driver and arah_M30 != "WAIT": score += 20
    if arah_M15 == m_driver and arah_M15 != "WAIT": score += 15
    
    conf_tier = "💎 PREMIUM" if score >= 80 else ("🔥 STRONG" if score >= 60 else "⚠️ MODERATE")
    
    d1_tag = "BASE"
    h4_tag = "CF" if arah_H4 == arah_D else "VR"
    h1_tag = "CF" if arah_H1 == arah_H4 else "VR"
    m30_tag = "CF" if arah_M30 == arah_H1 else "VR"
    m15_tag = "CF" if arah_M15 == arah_M30 else "VR"
    m5_tag = "SNIPER" if arah_M5 == arah_M30 else "WAIT"
    
    is_choppy = False 
    
    regime = "🛑 SQUEEZE" if is_choppy else ("🌊 CF TSUNAMI" if arah_H4 == arah_H1 else "⚡ VR RETEST")
    eng_name = "EN-1: CF EXP" if (arah_H4 == arah_H1 and arah_H4 != "WAIT") else ("EN-2: VR RETEST" if (arah_H4 != "WAIT" and arah_H1 != "WAIT") else "MONITOR")
    
    plan_active = True
    plan_is_buy = m_driver == "BUY"
    
    act_badge = "🟢 BUY SNIPER" if plan_is_buy else "🔴 SELL SNIPER"
    if not plan_active:
        act_badge = "⏸️ WAIT"
        
    supM30 = current_price - 2.5
    resM30 = current_price + 2.5
    
    if plan_is_buy:
        rec_entry_zone = f"{round(supM30, 2)} - {round(current_price, 2)}"
    else:
        rec_entry_zone = f"{round(current_price, 2)} - {round(resM30, 2)}"
        
    return {
        "timestamp": int(time.time()),
        "symbol": "XAUUSD",
        "current_price": round(current_price, 2),
        "v10": {
            "score": score,
            "conf_tier": conf_tier,
            "d1_bias": arah_D, "d1_tag": d1_tag,
            "h4_bias": arah_H4, "h4_tag": h4_tag,
            "h1_bias": arah_H1, "h1_tag": h1_tag,
            "m30_bias": arah_M30, "m30_tag": m30_tag,
            "m15_bias": arah_M15, "m15_tag": m15_tag,
            "m5_bias": arah_M5, "m5_tag": m5_tag,
            "regime": regime,
            "eng_name": eng_name,
            "act_badge": act_badge,
            "act_plan": f"Zona: {rec_entry_zone}",
            "m30_in_h4": 3,
            "m5_in_m30": 2
        },
        "trade_plan": {
            "action": "BUY" if plan_is_buy else "SELL",
            "entry": round(current_price, 2),
            "sl": round(current_price - 3.5 if plan_is_buy else current_price + 3.5, 2),
            "tp1": round(current_price + 7.0 if plan_is_buy else current_price - 7.0, 2),
            "tp2": round(current_price + 12.0 if plan_is_buy else current_price - 12.0, 2),
            "sl_pips": 35.0,
            "tp1_pips": 70.0
        },
        "cmp_levels": levels,
        "barriers": barriers
    }
