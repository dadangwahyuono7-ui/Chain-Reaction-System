# 🚀 CHAIN REACTION PRO — CUSTOM CHART ENGINE (HANDOVER PC UTAMA)

Folder ini (`custom-chart-engine`) sudah bersifat **standalone & portable**. Anda tinggal meng-copy seluruh isi folder ini ke PC Trading utama Anda nanti malam.

---

## 📂 Struktur Folder
```
custom-chart-engine/
├── START_CHART_ENGINE.bat     <-- Cukup double-click file ini untuk menjalankan semua sistem
├── server.py                  <-- Python FastAPI Server (WebSocket Live MT5, History Data & Bookmap Depth)
├── storyline_calc.py          <-- Engine Storyline Pro v10.2 (Score %, Regime, Confluence, Sniper Zone)
├── requirements.txt           <-- Daftar library python yang dibutuhkan
├── README_HANDOVER_PC.md      <-- Panduan ini
└── public/                    <-- Frontend Web (Lightweight Charts + Drawing Engine TV-Style)
    ├── index.html             <-- Layout Terminal (Quad Multi-Window + HUD Mobile Slim Widget v10.2)
    ├── style.css              <-- Styling Obsidian Futuristic (Dark Gold & Neon Cyan)
    ├── core/
    │   ├── App.js             <-- Main Application Entry Point
    │   ├── Constants.js       <-- Timeframe & Grid Layout Constants
    │   └── CMPLogic.js        <-- Logic Minor SnR Breakout
    ├── charts/
    │   ├── ChartWindow.js     <-- Single Chart Window instance (Indicators, Timeframe switch, Volume)
    │   └── WindowManager.js   <-- Grid Manager, Synced Crosshair, Sync Time Range & Cockpit HUD updater
    └── drawings/
        ├── DrawingEngine.js   <-- Buttery-smooth Drawing Engine (Trendline, Crossline, Fib, Box, Deletion)
        └── DrawingStore.js    <-- Central Drawing State & Persistence
```

---

## ⚡ Cara Menjalankan di PC Utama
1. Buka folder `custom-chart-engine` di PC utama.
2. Jika Python baru diinstal, buka terminal di folder ini dan jalankan:
   ```bash
   pip install -r requirements.txt
   ```
3. Pastikan aplikasi **MetaTrader 5** (broker Anda) dalam kondisi **Terbuka / Login** (agar API Python MT5 bisa menarik live candle dan tick XAUUSD).
4. Double-click file:
   👉 **`START_CHART_ENGINE.bat`**
5. Browser akan otomatis terbuka ke `http://localhost:8800`.

---

## 🎯 Fitur yang Sudah Selesai & Berfungsi 100%:
1. **Multi-Window Sync**: Layout Single, Dual, Quad dengan pemilihan Timeframe individual (M1, M5, M15, M30, H1, H4, D1).
2. **Synced Crosshair**: Menggeser kursor di 1 window otomatis memandu garis crosshair di window lainnya.
3. **HUD Mobile Slim Widget (v10.2)**:
   - Header: `👑 CR PRO • M30 [x/8]` + `Confluence Score %`
   - Baris Pasangan Cascade: `D1 [BASE]`, `H4 [VR/CF]`, `H1 [VR/CF]`, `M30 [VR/CF]`, `M15 [VR/CF]`, `M5 [SNIPER/WAIT]`
   - Baris Regime & Engine: `⚡ VR RETEST / 🌊 CF TSUNAMI` + `EN-1 / EN-2`
   - Baris Action Sniper: `🟢 BUY SNIPER / 🔴 SELL SNIPER` + `Zona Entry`
4. **Liquidity Walls (Depth Ladder Bookmap)**: Menampilkan ladder likuiditas ASK/BID dan posisi CMP.
5. **Drawing Engine Lengkap**:
   - Trendline, Ray, Horizontal Line, Vertical Line, **Cross Line** (bisa dihapus dengan klik + tekan `Delete`/`Backspace`), Rectangle, Fibonacci, Text, dsb.
   - Tombol Magnet Mode, Stay in Draw Mode, Lock All, Hide All, Clear All.

---

## 🤖 Catatan untuk AI Selanjutnya di PC Utama:
Jika ingin menghubungkan langsung dengan file output EA MT5 (`sultan_status.json` / `live_status.json` di `Common/Files`):
- Buka `server.py`, arahkan pembacaan file JSON ke direktori `C:\Users\<User>\AppData\Roaming\MetaQuotes\Terminal\Common\Files\sultan_status.json`.
- Seluruh frontend web sudah siap menerima dan menampilkan datanya secara realtime.
