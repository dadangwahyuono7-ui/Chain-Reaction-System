/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  MULTI-WINDOW ENGINE & TIMEFRAME RESAMPLING ORCHESTRATOR (PHASE 1)
 *  By Dadang Wahyuono
 *  - 21 Supported Chart Timeframes (Aggregation Engine)
 *  - Storyline Pro Cockpit Connection (Fractals, CMP, Depth Ladder)
 *  - SMA / EMA Indicators Engine & Custom Settings Manager
 *  - Full State Persistence (Layout, Symbols, Timeframes, Indicators, Volume, Settings)
 *  - Right Price Scale Countdown to Bar Close (1:1 TradingView)
 * ═══════════════════════════════════════════════════════════════════════════
 */

import { globalDrawingStore } from '../drawings/DrawingStore.js';
import { DrawingEngine } from '../drawings/DrawingEngine.js?v=7';

import { ALL_21_TIMEFRAMES, TF_SECONDS_MAP, POPULAR_SYMBOLS } from '../core/Constants.js';

const CHART_TYPES = [
  { id: "candles",   label: "🕯️", title: "Candlestick" },
  { id: "line",      label: "📈", title: "Line Chart" }
];

// Mathematical Indicators Calculators
function calculateEMA(candles, period) {
  if (!candles || candles.length < period) return [];
  const k = 2 / (period + 1);
  const emaData = [];

  let sum = 0;
  for (let i = 0; i < period; i++) {
    sum += candles[i].close;
  }
  let prevEma = sum / period;
  emaData.push({ time: candles[period - 1].time, value: Number(prevEma.toFixed(4)) });

  for (let i = period; i < candles.length; i++) {
    const currentPrice = candles[i].close;
    const currentEma = (currentPrice - prevEma) * k + prevEma;
    emaData.push({ time: candles[i].time, value: Number(currentEma.toFixed(4)) });
    prevEma = currentEma;
  }
  return emaData;
}

function calculateSMA(candles, period) {
  if (!candles || candles.length < period) return [];
  const smaData = [];
  let sum = 0;

  for (let i = 0; i < period; i++) {
    sum += candles[i].close;
  }
  smaData.push({ time: candles[period - 1].time, value: Number((sum / period).toFixed(4)) });

  for (let i = period; i < candles.length; i++) {
    sum += candles[i].close - candles[i - period].close;
    smaData.push({ time: candles[i].time, value: Number((sum / period).toFixed(4)) });
  }
  return smaData;
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. INDIVIDUAL CHART WINDOW INSTANCE
// ─────────────────────────────────────────────────────────────────────────────
export class ChartWindow {
  constructor(windowManager, id, config = {}) {
    this.wm = windowManager;
    this.id = id;
    this.symbol = (config.symbol || "XAUUSD").toUpperCase();
    this.timeframe = (config.timeframe || "M5").toUpperCase();
    this.chartType = config.chartType || "candles";
    this.initialIndicators = config.indicators || null;
    this.initialVolumeVisible = config.volumeVisible !== undefined ? config.volumeVisible : true;

    this.candles = [];
    this.lastCandle = null;
    this.currentPrice = 0;
    this.isMaximized = false;
    this.isLoading = false;

    // Active indicators Map: key -> { id, type, period, color, series, visible, chipEl }
    this.activeIndicators = new Map();

    // DOM references
    this.el = null;
    this.chartContainer = null;
    this.legendEl = null;
    this.indicatorsLegendEl = null;
    this.volumeChipEl = null;
    this.volumeVisible = true;
    this.chart = null;
    this.candleSeries = null;
    this.volumeSeries = null;
    this.drawingEngine = null;
    this.resizeObserver = null;
    this.timerInterval = null;

    this.createDOM();
    this.initChart();
    this.loadHistory();
  }

  createDOM() {
    this.el = document.createElement("div");
    this.el.className = "chart-window";
    this.el.id = `chart-window-${this.id}`;

    this.el.innerHTML = `
      <div class="window-header">
        <div class="win-left-controls">
          <span class="win-badge">${this.id}</span>

          <!-- Symbol Selector (search-style like TradingView) -->
          <div class="sym-search-wrap">
            <input type="text" class="sym-search-input" value="${this.symbol}" title="Symbol (ketik simbol lalu Enter)" autocomplete="off" />
            <div class="sym-search-dropdown">
              ${POPULAR_SYMBOLS.map(s => `<div class="sym-dd-item" data-sym="${s}">${s}</div>`).join("")}
            </div>
          </div>

          <!-- Chart Type Selector (Candle / Line) -->
          <div class="win-chart-type-wrap">
            ${CHART_TYPES.map(ct => `<button class="win-act-btn btn-chart-type ${ct.id === this.chartType ? "active" : ""}" data-ctype="${ct.id}" title="${ct.title}">${ct.label}</button>`).join("")}
          </div>

          <!-- Timeframe Quick Selector -->
          <div class="win-tf-bar">
            ${["M1", "M5", "M15", "M30", "H1", "H4", "D1"].map(tf => `
              <button class="win-tf-btn ${tf === this.timeframe ? "active" : ""}" data-tf="${tf}">${tf}</button>
            `).join("")}

            <!-- 21 Timeframe Dropdown -->
            <div class="tf-dropdown-wrap">
              <button class="win-tf-btn tf-more-btn" title="All 21 Timeframes">▼</button>
              <div class="tf-flyout-menu">
                <div class="tf-flyout-header">Minutes</div>
                <div class="tf-flyout-grid">
                  ${["M1", "M2", "M3", "M4", "M5", "M6", "M10", "M12", "M15", "M20", "M30"].map(tf => `
                    <div class="tf-flyout-item ${tf === this.timeframe ? "active" : ""}" data-tf="${tf}">${tf}</div>
                  `).join("")}
                </div>
                <div class="tf-flyout-header">Hours</div>
                <div class="tf-flyout-grid">
                  ${["H1", "H2", "H3", "H4", "H6", "H8", "H12"].map(tf => `
                    <div class="tf-flyout-item ${tf === this.timeframe ? "active" : ""}" data-tf="${tf}">${tf}</div>
                  `).join("")}
                </div>
                <div class="tf-flyout-header">Daily / Weekly</div>
                <div class="tf-flyout-grid">
                  ${["D1", "W1", "MN1"].map(tf => `
                    <div class="tf-flyout-item ${tf === this.timeframe ? "active" : ""}" data-tf="${tf}">${tf}</div>
                  `).join("")}
                </div>
              </div>
            </div>
          </div>

          <!-- Quick Indicators Button -->
          <button class="win-act-btn btn-win-indicators" title="Add Indicators (EMA, SMA)">ƒx</button>
        </div>

        <!-- OHLC Legend & Candle Closing Countdown Timer -->
        <div class="win-ohlc-legend">
          <span class="leg-item leg-sym">${this.symbol}</span>
          <span class="leg-item leg-tf">${this.timeframe}</span>
          <span class="leg-item">O:<b class="val-o">0.00</b></span>
          <span class="leg-item">H:<b class="val-h">0.00</b></span>
          <span class="leg-item">L:<b class="val-l">0.00</b></span>
          <span class="leg-item">C:<b class="val-c">0.00</b></span>
          <span class="leg-item">V:<b class="val-v">0</b></span>
          <span class="win-candle-timer" title="Time remaining until active candle close">⏳ <b class="val-timer">--:--</b></span>
          <span class="win-bar-count" title="Candles loaded">📊 <b class="val-bar-count">0</b> bars</span>
        </div>

        <!-- Right Window Actions -->
        <div class="win-right-controls">
          <button class="win-act-btn btn-autoscale active" title="Auto-Scale Price Axis (A)">A</button>
          <button class="win-act-btn btn-log-scale" title="Log Scale (L)">Log</button>
          <button class="win-act-btn btn-jump-latest" title="Jump to Latest Candle">⏭</button>
          <button class="win-act-btn btn-zoom-in" title="Zoom In (+)">➕</button>
          <button class="win-act-btn btn-zoom-out" title="Zoom Out (-)">➖</button>
          <button class="win-act-btn btn-fit-content" title="Auto Fit">⛶</button>
          <button class="win-act-btn btn-screenshot" title="Screenshot Chart">📷</button>
          <button class="win-act-btn btn-maximize-win" title="Maximize / Restore">🗖</button>
        </div>
      </div>

      <!-- Chart Canvas Viewport -->
      <div class="window-chart-container">
        <!-- Floating On-Chart Indicator Legend -->
        <div class="win-indicators-legend-wrapper">
          <button class="win-act-btn btn-toggle-indicators" title="Show/Hide Indicators Legend">👁️</button>
          <div class="win-indicators-legend"></div>
        </div>
        <!-- Bottom Status Bar (TradingView Style) -->
        <div class="win-status-bar">
          <span class="sb-cursor-date">—</span>
          <span class="sb-sep">|</span>
          <span class="sb-cursor-price">—</span>
          <span class="sb-sep">|</span>
          <span class="sb-bars-visible">— bars visible</span>
        </div>
      </div>
    `;

    this.chartContainer = this.el.querySelector(".window-chart-container");
    this.legendEl = this.el.querySelector(".win-ohlc-legend");
    this.indicatorsLegendEl = this.el.querySelector(".win-indicators-legend");
    this.indicatorsLegendWrapper = this.el.querySelector(".win-indicators-legend-wrapper");
    this.btnToggleIndicators = this.el.querySelector(".btn-toggle-indicators");

    this.bindDOMEvents();
  }

  bindDOMEvents() {
    // --- Symbol Search Input (TradingView style) ---
    const symInput = this.el.querySelector(".sym-search-input");
    const symDropdown = this.el.querySelector(".sym-search-dropdown");

    symInput.addEventListener("focus", () => symDropdown.classList.add("show"));
    symInput.addEventListener("blur", () => setTimeout(() => symDropdown.classList.remove("show"), 180));
    symInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        const val = symInput.value.trim().toUpperCase();
        if (val) this.setSymbol(val);
        symDropdown.classList.remove("show");
        symInput.blur();
      }
    });
    symInput.addEventListener("input", () => {
      const q = symInput.value.toUpperCase();
      this.el.querySelectorAll(".sym-dd-item").forEach(item => {
        item.style.display = item.dataset.sym.includes(q) ? "" : "none";
      });
    });
    this.el.querySelectorAll(".sym-dd-item").forEach(item => {
      item.addEventListener("mousedown", (e) => {
        e.preventDefault();
        this.setSymbol(item.dataset.sym);
        symInput.value = item.dataset.sym;
        symDropdown.classList.remove("show");
      });
    });

    // --- Chart Type Selector (Candle / Line) ---
    this.el.querySelectorAll(".btn-chart-type").forEach(btn => {
      btn.addEventListener("click", () => {
        this.setChartType(btn.dataset.ctype);
      });
    });

    // --- Timeframe Buttons ---
    this.el.querySelectorAll(".win-tf-btn[data-tf]").forEach(btn => {
      btn.addEventListener("click", () => {
        this.setTimeframe(btn.dataset.tf);
      });
    });

    const flyout = this.el.querySelector(".tf-flyout-menu");
    const moreBtn = this.el.querySelector(".tf-more-btn");

    moreBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      flyout.classList.toggle("show");
    });
    document.addEventListener("click", () => flyout.classList.remove("show"));

    this.el.querySelectorAll(".tf-flyout-item[data-tf]").forEach(item => {
      item.addEventListener("click", (e) => {
        e.stopPropagation();
        this.setTimeframe(item.dataset.tf);
        flyout.classList.remove("show");
      });
    });

    // --- Indicators ---
    const indBtn = this.el.querySelector(".btn-win-indicators");
    if (indBtn) {
      indBtn.addEventListener("click", () => {
        window.openIndicatorsModalForWindow(this);
      });
    }

    // --- Auto-Scale Toggle ---
    const btnAutoScale = this.el.querySelector(".btn-autoscale");
    if (btnAutoScale) {
      btnAutoScale.addEventListener("click", () => {
        this.isAutoScale = !this.isAutoScale;
        this.chart.priceScale("right").applyOptions({ autoScale: this.isAutoScale });
        btnAutoScale.classList.toggle("active", this.isAutoScale);
        if (window.showToast) window.showToast(this.isAutoScale ? "📐 Auto-Scale ON" : "📐 Auto-Scale OFF");
      });
    }

    // --- Log Scale Toggle ---
    const btnLogScale = this.el.querySelector(".btn-log-scale");
    if (btnLogScale) {
      btnLogScale.addEventListener("click", () => {
        this.isLogScale = !this.isLogScale;
        this.chart.priceScale("right").applyOptions({ mode: this.isLogScale ? 1 : 0 });
        btnLogScale.classList.toggle("active", this.isLogScale);
        if (window.showToast) window.showToast(this.isLogScale ? "📊 Log Scale ON" : "📊 Log Scale OFF");
      });
    }

    // --- Screenshot ---
    const btnScreenshot = this.el.querySelector(".btn-screenshot");
    if (btnScreenshot) {
      btnScreenshot.addEventListener("click", () => {
        try {
          const canvas = this.chartContainer.querySelector("canvas");
          if (canvas) {
            const link = document.createElement("a");
            link.download = `chart_${this.symbol}_${this.timeframe}_${Date.now()}.png`;
            link.href = canvas.toDataURL("image/png");
            link.click();
            if (window.showToast) window.showToast("📷 Screenshot saved!");
          }
        } catch(e) {
          if (window.showToast) window.showToast("📷 Screenshot failed (canvas restriction)");
        }
      });
    }

    // --- Zoom, Fit, Maximize ---
    this.el.querySelector(".btn-zoom-in").addEventListener("click", () => this.zoom(0.75));
    this.el.querySelector(".btn-zoom-out").addEventListener("click", () => this.zoom(1.35));
    this.el.querySelector(".btn-fit-content").addEventListener("click", () => this.chart.timeScale().fitContent());
    this.el.querySelector(".btn-jump-latest").addEventListener("click", () => this.chart.timeScale().scrollToRealTime());
    this.el.querySelector(".btn-maximize-win").addEventListener("click", () => this.wm.toggleMaximizeWindow(this));

    if (this.btnToggleIndicators) {
      this.btnToggleIndicators.addEventListener("click", (e) => {
        e.stopPropagation();
        this.indicatorsLegendWrapper.classList.toggle("collapsed");
      });
    }
  }

  initChart() {
    this.chart = LightweightCharts.createChart(this.chartContainer, {
      width: this.chartContainer.clientWidth || 400,
      height: this.chartContainer.clientHeight || 300,
      layout: {
        background: { type: "solid", color: "#07090e" },
        textColor: "#94a3b8",
        fontSize: 11,
        fontFamily: "'JetBrains Mono', 'Inter', monospace"
      },
      grid: {
        vertLines: { color: "rgba(255, 255, 255, 0.04)" },
        horzLines: { color: "rgba(255, 255, 255, 0.04)" }
      },
      crosshair: {
        mode: LightweightCharts.CrosshairMode.Normal,
        vertLine: { color: "rgba(0, 240, 255, 0.5)", width: 1, style: 3, labelBackgroundColor: "#0f172a" },
        horzLine: { color: "rgba(0, 240, 255, 0.5)", width: 1, style: 3, labelBackgroundColor: "#0f172a" }
      },
      timeScale: {
        borderColor: "#1e293b",
        timeVisible: true,
        secondsVisible: false,
        rightOffset: 12,
        barSpacing: 10,
        minBarSpacing: 2
      },
      rightPriceScale: {
        borderColor: "#1e293b",
        scaleMargins: {
          top: 0.02,
          bottom: 0.02
        },
        autoScale: true,
        alignLabels: true
      },
      handleScroll: {
        mouseWheel: true,
        pressedMouseMove: true,
        horzTouchDrag: true,
        vertTouchDrag: true
      },
      handleScale: {
        axisPressedMouseMove: true,
        mouseWheel: true,
        pinch: true,
        axisReset: true
      }
    });

    const isCurrency = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    this.candleSeries = this.chart.addCandlestickSeries({
      upColor: "#00e676",
      downColor: "#ff334b",
      borderVisible: false,
      wickUpColor: "#00e676",
      wickDownColor: "#ff334b",
      priceFormat: {
        type: "price",
        precision: isCurrency ? 4 : 2,
        minMove: isCurrency ? 0.0001 : 0.01
      }
    });

    this.volumeSeries = this.chart.addHistogramSeries({
      color: "rgba(56, 189, 248, 0.18)",
      priceFormat: { type: "volume" },
      priceScaleId: `vol_${this.id}`,
      scaleMargins: {
        top: 0.86,
        bottom: 0
      }
    });

    this.chart.priceScale(`vol_${this.id}`).applyOptions({
      scaleMargins: { top: 0.86, bottom: 0 },
      visible: false
    });

    this.drawingEngine = new DrawingEngine(this);

    this.chart.subscribeCrosshairMove((param) => {
      if (!param.time || !param.seriesData.get(this.candleSeries)) {
        this.updateLegend(this.lastCandle);
        this.updateIndicatorValues(this.lastCandle?.time);
        this.updateStatusBar(null, null);
        return;
      }
      const data = param.seriesData.get(this.candleSeries);
      this.updateLegend(data);
      this.updateIndicatorValues(param.time);
      this.updateStatusBar(param.time, data?.close || 0);

      if (this.wm.isCrosshairLinked && param.time) {
        this.wm.broadcastCrosshair(this.id, param.time, data?.close || 0);
      }
    });

    // Update bars visible count on scroll/zoom
    this.chart.timeScale().subscribeVisibleLogicalRangeChange(() => {
      this.updateBarsVisible();
    });


    this.chartContainer.addEventListener("wheel", (e) => {
      e.preventDefault();
      const logicalRange = this.chart.timeScale().getVisibleLogicalRange();
      if (!logicalRange) return;
      const zoomStep = 0.05; // Smoother zoom (was 0.12)
      const factor = e.deltaY > 0 ? (1 + zoomStep) : (1 - zoomStep);
      const rangeLen = logicalRange.to - logicalRange.from;
      const newRangeLen = Math.max(10, rangeLen * factor);
      const center = (logicalRange.from + logicalRange.to) / 2;
      this.chart.timeScale().setVisibleLogicalRange({
        from: center - (newRangeLen / 2),
        to: center + (newRangeLen / 2)
      });
      if (this.drawingEngine) this.drawingEngine.requestRender();
    }, { passive: false });

    this.chartContainer.addEventListener("dblclick", () => {
      this.chart.timeScale().fitContent();
    });

    this.timerInterval = setInterval(() => this.updateCountdownTimer(), 1000);

    // Right Price Scale Countdown Badge (TradingView Style on Axis)
    this.priceScaleCountdownBadge = document.createElement("div");
    this.priceScaleCountdownBadge.className = "price-scale-countdown-badge";
    this.priceScaleCountdownBadge.textContent = "--:--";
    this.chartContainer.appendChild(this.priceScaleCountdownBadge);

    // Volume On-Chart Legend Chip (1-Click Hide / Remove like TradingView)
    this.volumeChipEl = document.createElement("div");
    this.volumeChipEl.className = "indicator-chip";
    this.volumeChipEl.dataset.id = "volume";
    this.volumeChipEl.style.borderColor = "#38bdf844";
    this.volumeChipEl.innerHTML = `
      <span class="ind-dot" style="background: #38bdf8;"></span>
      <span class="ind-label" style="color: #38bdf8;">Vol:</span>
      <span class="ind-val val-vol-chip">--</span>
      <button class="ind-action-btn ind-eye" title="Hide/Show Volume">👁️</button>
      <button class="ind-action-btn del ind-del" title="Remove Volume Histogram (Hapus)">✖</button>
    `;

    this.volumeVisible = (this.wm.globalChartConfig?.showVolume !== false) && (this.initialVolumeVisible !== false);
    this.volumeSeries.applyOptions({ visible: this.volumeVisible });
    this.volumeChipEl.classList.toggle("hidden-line", !this.volumeVisible);
    if (this.wm.globalChartConfig?.showVolume === false) {
      this.volumeChipEl.style.display = "none";
    }

    this.volumeChipEl.querySelector(".ind-eye").addEventListener("click", (e) => {
      e.stopPropagation();
      this.volumeVisible = !this.volumeVisible;
      this.volumeSeries.applyOptions({ visible: this.volumeVisible });
      this.volumeChipEl.classList.toggle("hidden-line", !this.volumeVisible);
      this.volumeChipEl.querySelector(".ind-eye").textContent = this.volumeVisible ? "👁️" : "🚫";
      this.wm.saveState();
    });

    this.volumeChipEl.querySelector(".ind-del").addEventListener("click", (e) => {
      e.stopPropagation();
      this.volumeVisible = false;
      this.volumeSeries.applyOptions({ visible: false });
      if (this.volumeChipEl.parentNode) {
        this.volumeChipEl.parentNode.removeChild(this.volumeChipEl);
      }
      this.wm.saveState();
      if (window.showToast) window.showToast("🗑️ Volume Histogram removed");
    });

    this.indicatorsLegendEl.appendChild(this.volumeChipEl);

    // Apply global settings
    if (this.wm.globalChartConfig) {
      this.applyChartSettings(this.wm.globalChartConfig);
    }

    // Restore saved indicators or defaults if none exist
    if (Array.isArray(this.initialIndicators)) {
      this.initialIndicators.forEach(ind => {
        this.addIndicator(ind.type, ind.period, ind.color, ind.visible !== false, false);
      });
    } else if (this.id === 1 && !this.wm.hasSavedState) {
      this.addIndicator("EMA", 21, "#ffb703", true, false);
    }

    this.resizeObserver = new ResizeObserver(() => {
      this.resize();
    });
    this.resizeObserver.observe(this.chartContainer);
  }

  applyChartSettings(cfg) {
    if (!cfg) return;

    if (this.candleSeries) {
      this.candleSeries.applyOptions({
        upColor: cfg.candleUp || "#00e676",
        downColor: cfg.candleDown || "#ff334b",
        wickUpColor: cfg.wickUp || "#00e676",
        wickDownColor: cfg.wickDown || "#ff334b",
        borderVisible: false
      });
    }

    if (this.chart) {
      this.chart.applyOptions({
        layout: {
          background: { color: cfg.chartBg || "#07090e" }
        },
        grid: {
          vertLines: {
            color: cfg.showGrid ? (cfg.gridColor || "rgba(255, 255, 255, 0.04)") : "transparent"
          },
          horzLines: {
            color: cfg.showGrid ? (cfg.gridColor || "rgba(255, 255, 255, 0.04)") : "transparent"
          }
        }
      });
    }

    if (this.priceScaleCountdownBadge) {
      this.priceScaleCountdownBadge.classList.toggle("hidden", !cfg.showCountdown);
    }

    if (this.volumeSeries) {
      const showVol = cfg.showVolume !== false && this.volumeVisible;
      this.volumeSeries.applyOptions({
        visible: showVol
      });
      if (this.volumeChipEl) {
        this.volumeChipEl.style.display = (cfg.showVolume !== false && this.volumeChipEl.parentNode) ? "flex" : "none";
      }
    }

    if (this.legendEl) {
      this.legendEl.style.display = cfg.showOHLC !== false ? "flex" : "none";
    }
  }

  getStateObject() {
    const indicatorsArr = [];
    this.activeIndicators.forEach(ind => {
      indicatorsArr.push({
        type: ind.type,
        period: ind.period,
        color: ind.color,
        visible: ind.visible
      });
    });

    return {
      id: this.id,
      symbol: this.symbol,
      timeframe: this.timeframe,
      chartType: this.chartType || "candles",
      volumeVisible: this.volumeVisible !== false,
      indicators: indicatorsArr
    };
  }

  // ─────────────────────────────────────────────────────────────────────────
  // INDICATOR SYSTEM: ADD, REMOVE, HIDE/SHOW, EDIT
  // ─────────────────────────────────────────────────────────────────────────
  addIndicator(type, period, color, visible = true, triggerSave = true) {
    const id = `${type.toLowerCase()}_${period}`;
    if (this.activeIndicators.has(id)) {
      if (triggerSave && window.showToast) window.showToast(`⚠️ ${type} ${period} is already on this chart`);
      return;
    }

    const isCurrency = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    const lineSeries = this.chart.addLineSeries({
      color: color,
      lineWidth: 2,
      priceLineVisible: false,
      lastValueVisible: true,
      visible: visible,
      priceFormat: {
        type: "price",
        precision: isCurrency ? 4 : 2,
        minMove: isCurrency ? 0.0001 : 0.01
      }
    });

    const chip = document.createElement("div");
    chip.className = `indicator-chip ${visible ? "" : "hidden-line"}`;
    chip.dataset.id = id;
    chip.style.borderColor = `${color}44`;
    chip.innerHTML = `
      <span class="ind-dot" style="background: ${color};"></span>
      <span class="ind-label" style="color: ${color};">${type} ${period}:</span>
      <span class="ind-val">--</span>
      <button class="ind-action-btn ind-gear" title="Settings (Ubah Periode / Warna)">⚙</button>
      <button class="ind-action-btn ind-eye" title="Hide/Show Indicator">${visible ? "👁️" : "🚫"}</button>
      <button class="ind-action-btn del ind-del" title="Remove Indicator (Hapus)">✖</button>
    `;

    chip.querySelector(".ind-gear").addEventListener("click", (e) => {
      e.stopPropagation();
      if (window.openIndicatorSettingsModal) {
        window.openIndicatorSettingsModal(this, id);
      }
    });

    chip.querySelector(".ind-eye").addEventListener("click", (e) => {
      e.stopPropagation();
      this.wm.windows.forEach(w => {
        if (w.activeIndicators.has(id)) w.toggleIndicatorVisibility(id, false);
      });
      if (window.showToast) window.showToast("Indicator Visibility Toggled");
    });

    chip.querySelector(".ind-del").addEventListener("click", (e) => {
      e.stopPropagation();
      this.wm.windows.forEach(w => {
        if (w.activeIndicators.has(id)) w.removeIndicator(id, false);
      });
      if (window.showToast) window.showToast("Indicator Removed");
    });

    this.indicatorsLegendEl.appendChild(chip);

    const indObj = {
      id,
      type,
      period,
      color,
      series: lineSeries,
      visible: visible,
      chipEl: chip,
      data: []
    };

    this.activeIndicators.set(id, indObj);
    this.recalculateIndicator(indObj);

    if (triggerSave) {
      if (window.showToast) window.showToast(`✅ ${type} ${period} added to Chart ${this.id}`);
      this.wm.saveState();
    }
  }

  updateIndicatorConfig(id, newType, newPeriod, newColor) {
    const ind = this.activeIndicators.get(id);
    if (!ind) return;

    const newId = `${newType.toLowerCase()}_${newPeriod}`;
    if (newId !== id && this.activeIndicators.has(newId)) {
      if (window.showToast) window.showToast(`⚠️ ${newType} ${newPeriod} is already on this chart`);
      return;
    }

    ind.type = newType;
    ind.period = newPeriod;
    ind.color = newColor;
    ind.series.applyOptions({ color: newColor });

    ind.chipEl.dataset.id = newId;
    ind.chipEl.style.borderColor = `${newColor}44`;
    ind.chipEl.querySelector(".ind-dot").style.background = newColor;
    ind.chipEl.querySelector(".ind-label").style.color = newColor;
    ind.chipEl.querySelector(".ind-label").textContent = `${newType} ${newPeriod}:`;

    if (newId !== id) {
      this.activeIndicators.delete(id);
      ind.id = newId;
      this.activeIndicators.set(newId, ind);
    }

    this.recalculateIndicator(ind);
    this.wm.saveState();
    if (window.showToast) window.showToast(`⚙ ${newType} ${newPeriod} updated`);
  }

  removeIndicator(id) {
    const ind = this.activeIndicators.get(id);
    if (!ind) return;

    if (ind.series) {
      this.chart.removeSeries(ind.series);
    }
    if (ind.chipEl && ind.chipEl.parentNode) {
      ind.chipEl.parentNode.removeChild(ind.chipEl);
    }

    this.activeIndicators.delete(id);
    this.wm.saveState();
    if (window.showToast) window.showToast(`🗑️ ${ind.type} ${ind.period} removed`);
  }

  toggleIndicatorVisibility(id) {
    const ind = this.activeIndicators.get(id);
    if (!ind) return;

    ind.visible = !ind.visible;
    ind.series.applyOptions({ visible: ind.visible });
    ind.chipEl.classList.toggle("hidden-line", !ind.visible);
    ind.chipEl.querySelector(".ind-eye").textContent = ind.visible ? "👁️" : "🚫";
    this.wm.saveState();
  }

  recalculateIndicator(ind) {
    if (!this.candles || this.candles.length === 0) return;
    if (ind.type === "EMA") {
      ind.data = calculateEMA(this.candles, ind.period);
    } else if (ind.type === "SMA") {
      ind.data = calculateSMA(this.candles, ind.period);
    }
    ind.series.setData(ind.data);
    this.updateIndicatorValues(this.lastCandle?.time);
  }

  recalculateAllIndicators() {
    this.activeIndicators.forEach(ind => {
      this.recalculateIndicator(ind);
    });
  }

  updateIndicatorValues(time) {
    if (!time) return;
    const isCurrency = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    const p = isCurrency ? 4 : 2;

    this.activeIndicators.forEach(ind => {
      if (!ind.data || ind.data.length === 0) return;
      const pt = ind.data.find(d => d.time === time) || ind.data[ind.data.length - 1];
      if (pt && ind.chipEl) {
        ind.chipEl.querySelector(".ind-val").textContent = Number(pt.value).toFixed(p);
      }
    });
  }

  resize() {
    if (!this.chart || !this.chartContainer) return;
    const w = this.chartContainer.clientWidth;
    const h = this.chartContainer.clientHeight;
    if (w > 0 && h > 0) {
      this.chart.applyOptions({ width: w, height: h });
      if (this.drawingEngine) {
        this.drawingEngine.resizeCanvas();
      }
    }
  }

  zoom(factor) {
    const range = this.chart.timeScale().getVisibleLogicalRange();
    if (!range) return;
    const center = (range.from + range.to) / 2;
    const newHalf = ((range.to - range.from) * factor) / 2;
    this.chart.timeScale().setVisibleLogicalRange({
      from: center - newHalf,
      to: center + newHalf
    });
    if (this.drawingEngine) this.drawingEngine.requestRender();
  }

  updateLegend(c) {
    if (!c || !this.legendEl) return;
    const isCur = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    const p = isCur ? 4 : 2;

    this.legendEl.querySelector(".leg-sym").textContent = this.symbol;
    this.legendEl.querySelector(".leg-tf").textContent = this.timeframe;
    this.legendEl.querySelector(".val-o").textContent = Number(c.open).toFixed(p);
    this.legendEl.querySelector(".val-h").textContent = Number(c.high).toFixed(p);
    this.legendEl.querySelector(".val-l").textContent = Number(c.low).toFixed(p);
    this.legendEl.querySelector(".val-c").textContent = Number(c.close).toFixed(p);
    this.legendEl.querySelector(".val-v").textContent = (c.volume || 100).toLocaleString();

    if (this.volumeChipEl && c.volume !== undefined) {
      const volTxt = c.volume >= 1000 ? `${(c.volume / 1000).toFixed(1)}K` : c.volume.toString();
      const chipVal = this.volumeChipEl.querySelector(".val-vol-chip");
      if (chipVal) chipVal.textContent = volTxt;
    }
  }

  updateCountdownTimer() {
    const timerEl = this.el?.querySelector(".val-timer");
    const scaleBadge = this.priceScaleCountdownBadge;
    if (!this.lastCandle) return;

    const tfSec = TF_SECONDS_MAP[this.timeframe] || 60;
    const now = Math.floor(Date.now() / 1000);

    // Compensate for MT5 broker server timezone difference
    let serverTime = now;
    if (window.brokerTimeOffset !== undefined) {
      serverTime = now + window.brokerTimeOffset;
    } else if (this.lastCandle.time) {
      serverTime = this.lastCandle.time;
    }

    // Calculate remaining seconds strictly within the active timeframe slot
    const elapsedInCycle = (serverTime % tfSec);
    let remaining = tfSec - elapsedInCycle;
    
    // Strict clamp: remaining time can NEVER exceed the timeframe duration
    remaining = Math.min(tfSec, Math.max(0, remaining));

    const h = Math.floor(remaining / 3600);
    const m = Math.floor((remaining % 3600) / 60);
    const s = remaining % 60;

    let timerStr = "";
    if (h > 0) {
      timerStr = `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    } else {
      timerStr = `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
    }

    if (timerEl) timerEl.textContent = timerStr;

    if (scaleBadge && this.candleSeries && this.chartContainer) {
      scaleBadge.textContent = timerStr;
      const priceY = this.candleSeries.priceToCoordinate(this.lastCandle.close);
      if (priceY !== null && priceY > 10 && priceY < (this.chartContainer.clientHeight - 25)) {
        scaleBadge.style.top = `${priceY + 11}px`;
        scaleBadge.style.display = "block";
      } else {
        scaleBadge.style.display = "none";
      }
    }
  }


  async loadHistory() {
    this.isLoading = true;
    try {
      const res = await fetch(`/api/chart/history?symbol=${this.symbol}&tf=${this.timeframe}&count=500`);
      const data = await res.json();

      this.candles = data.candles || [];
      this.candleSeries.setData(this.candles);

      const volData = this.candles.map(c => ({
        time: c.time,
        value: c.volume || 100,
        color: c.close >= c.open ? "rgba(0, 230, 118, 0.25)" : "rgba(255, 51, 75, 0.25)"
      }));
      this.volumeSeries.setData(volData);

      if (this.candles.length > 0) {
        this.lastCandle = this.candles[this.candles.length - 1];
        this.currentPrice = this.lastCandle.close;
        const nowLocal = Math.floor(Date.now() / 1000);
        window.brokerTimeOffset = this.lastCandle.time - nowLocal;
        this.updateLegend(this.lastCandle);
        this.updateCountdownTimer();
        this.recalculateAllIndicators();

        // Update bar count in header
        const barCountEl = this.el.querySelector(".val-bar-count");
        if (barCountEl) barCountEl.textContent = this.candles.length;

        // Update line series if active
        if (this.chartType === "line" && this.lineSeries) {
          const lineData = this.candles.map(c => ({ time: c.time, value: c.close }));
          this.lineSeries.setData(lineData);
        }
      }

      this.chart.timeScale().fitContent();
      setTimeout(() => this.updateBarsVisible(), 100);
      if (this.drawingEngine) {
        this.drawingEngine.requestRender();
      }

      if (data.source) {
        this.wm.updateDataSourceStatus(data.source, data.is_demo_data);
      }

      if (this.id === 1) {
        this.wm.fetchStorylineAnalysis(this.symbol);
      }
    } catch (err) {
      console.error(`[Window ${this.id}] Error loading history:`, err);
    } finally {
      this.isLoading = false;
    }
  }

  setSymbol(newSymbol) {
    const sym = newSymbol.toUpperCase();
    if (this.symbol === sym) return;
    this.symbol = sym;

    // Update symbol search input
    const symInput = this.el.querySelector(".sym-search-input");
    if (symInput) symInput.value = this.symbol;

    // Update legend
    const legSym = this.el.querySelector(".leg-sym");
    if (legSym) legSym.textContent = this.symbol;

    const isCur = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    this.candleSeries.applyOptions({
      priceFormat: {
        type: "price",
        precision: isCur ? 4 : 2,
        minMove: isCur ? 0.0001 : 0.01
      }
    });

    this.loadHistory();
    this.wm.saveState();
  }

  setTimeframe(newTf) {
    if (this.timeframe === newTf) return;
    this.timeframe = newTf.toUpperCase();

    this.el.querySelectorAll(".win-tf-btn[data-tf]").forEach(b => {
      b.classList.toggle("active", b.dataset.tf === this.timeframe);
    });
    this.el.querySelectorAll(".tf-flyout-item[data-tf]").forEach(b => {
      b.classList.toggle("active", b.dataset.tf === this.timeframe);
    });

    // Update legend timeframe label
    const legTf = this.el.querySelector(".leg-tf");
    if (legTf) legTf.textContent = this.timeframe;

    this.loadHistory();
    this.wm.saveState();
  }

  setChartType(newType) {
    if (this.chartType === newType) return;
    this.chartType = newType;

    // Update chart type buttons
    this.el.querySelectorAll(".btn-chart-type").forEach(b => {
      b.classList.toggle("active", b.dataset.ctype === this.chartType);
    });

    if (newType === "line") {
      this.candleSeries.applyOptions({
        visible: false
      });
      // Add a line series if not already present
      if (!this.lineSeries) {
        const isCur = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
        this.lineSeries = this.chart.addLineSeries({
          color: "#00f0ff",
          lineWidth: 2,
          crosshairMarkerVisible: true,
          priceFormat: { type: "price", precision: isCur ? 4 : 2, minMove: isCur ? 0.0001 : 0.01 }
        });
        if (this.candles.length > 0) {
          const lineData = this.candles.map(c => ({ time: c.time, value: c.close }));
          this.lineSeries.setData(lineData);
        }
      } else {
        this.lineSeries.applyOptions({ visible: true });
      }
    } else {
      // candles
      this.candleSeries.applyOptions({ visible: true });
      if (this.lineSeries) this.lineSeries.applyOptions({ visible: false });
    }

    this.wm.saveState();
    if (window.showToast) window.showToast(`🕯️ Chart: ${newType === "candles" ? "Candlestick" : "Line"}`);
  }

  updateStatusBar(time, price) {
    const sb = this.el.querySelector(".win-status-bar");
    if (!sb) return;

    const dateEl = sb.querySelector(".sb-cursor-date");
    const priceEl = sb.querySelector(".sb-cursor-price");

    if (!time || !price) {
      if (dateEl) dateEl.textContent = "—";
      if (priceEl) priceEl.textContent = "—";
      return;
    }

    // Format date from unix timestamp
    const d = new Date(time * 1000);
    const dateStr = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")} ${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
    if (dateEl) dateEl.textContent = dateStr;

    const isCur = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    if (priceEl) priceEl.textContent = Number(price).toFixed(isCur ? 4 : 2);
  }

  updateBarsVisible() {
    const range = this.chart.timeScale().getVisibleLogicalRange();
    const sbEl = this.el.querySelector(".sb-bars-visible");
    if (range && sbEl) {
      const count = Math.round(range.to - range.from);
      sbEl.textContent = `${count} bars visible`;
    }
    // Also update bar count in header
    const barCountEl = this.el.querySelector(".val-bar-count");
    if (barCountEl && this.candles) {
      barCountEl.textContent = this.candles.length;
    }
  }

  handleTick(tick) {
    if (!tick || this.candles.length === 0) return;
    const price = tick.last;
    this.currentPrice = price;

    const tfSec = TF_SECONDS_MAP[this.timeframe] || 60;
    const nowLocal = Math.floor(Date.now() / 1000);
    if (tick.time) {
      window.brokerTimeOffset = tick.time - nowLocal;
    }
    const tickTime = tick.time || (nowLocal + (window.brokerTimeOffset || 0));
    const candleSlot = Math.floor(tickTime / tfSec) * tfSec;
    const isCur = (this.symbol.includes("USD") && !this.symbol.includes("XAU") && !this.symbol.includes("BTC"));
    const p = isCur ? 4 : 2;


    if (this.lastCandle && this.lastCandle.time === candleSlot) {
      this.lastCandle.high = Math.max(this.lastCandle.high, price);
      this.lastCandle.low = Math.min(this.lastCandle.low, price);
      this.lastCandle.close = Number(price.toFixed(p));
      this.lastCandle.volume = (this.lastCandle.volume || 0) + 1;
    } else {
      const newCandle = {
        time: candleSlot,
        open: Number(price.toFixed(p)),
        high: Number(price.toFixed(p)),
        low: Number(price.toFixed(p)),
        close: Number(price.toFixed(p)),
        volume: 1
      };
      this.candles.push(newCandle);
      this.lastCandle = newCandle;
    }

    this.candleSeries.update(this.lastCandle);
    this.volumeSeries.update({
      time: this.lastCandle.time,
      value: this.lastCandle.volume,
      color: this.lastCandle.close >= this.lastCandle.open ? "rgba(0, 230, 118, 0.25)" : "rgba(255, 51, 75, 0.25)"
    });

    this.updateLegend(this.lastCandle);
    this.updateCountdownTimer();

    this.activeIndicators.forEach(ind => {
      if (ind.type === "EMA" && ind.data.length > 0) {
        const k = 2 / (ind.period + 1);
        const prevEma = ind.data[ind.data.length - 1].value;
        const currentEma = Number(((price - prevEma) * k + prevEma).toFixed(4));
        ind.series.update({ time: this.lastCandle.time, value: currentEma });
        if (ind.chipEl) {
          ind.chipEl.querySelector(".ind-val").textContent = currentEma.toFixed(p);
        }
      }
    });
  }

  syncCrosshairTimestamp(timestamp) {
    if (!this.chart || !this.candleSeries) return;
    const targetCandle = this.candles.find(c => c.time === timestamp) ||
      this.candles.reduce((prev, curr) => Math.abs(curr.time - timestamp) < Math.abs(prev.time - timestamp) ? curr : prev, this.candles[0]);

    if (targetCandle) {
      this.updateLegend(targetCandle);
      this.updateIndicatorValues(targetCandle.time);
    }
  }

  destroy() {
    if (this.timerInterval) clearInterval(this.timerInterval);
    if (this.resizeObserver) this.resizeObserver.disconnect();
    if (this.drawingEngine) this.drawingEngine.destroy();
    if (this.chart) this.chart.remove();
    if (this.el && this.el.parentNode) {
      this.el.parentNode.removeChild(this.el);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 2. MULTI-WINDOW MANAGER ORCHESTRATOR
// ─────────────────────────────────────────────────────────────────────────────
export class WindowManager {
  constructor(gridContainerSelector) {
    this.container = document.querySelector(gridContainerSelector);
    this.windows = [];
    this.layout = "QUAD";
    this.isCrosshairLinked = false;
    this.activeTool = "cursor";
    this.maximizedWindow = null;
    this.ws = null;
    this.storylineInterval = null;
    this.hasSavedState = false;
    this.savedConfigs = null;

    this.globalChartConfig = {
      candleUp: "#00e676",
      candleDown: "#ff334b",
      wickUp: "#00e676",
      wickDown: "#ff334b",
      showCountdown: true,
      showLastPrice: true,
      showOHLC: true,
      showVolume: true,
      chartBg: "#07090e",
      gridColor: "rgba(255, 255, 255, 0.04)",
      showGrid: true,
      crosshairStyle: "dashed"
    };

    try {
      const rawCfg = localStorage.getItem("cd_chart_settings_v1");
      if (rawCfg) {
        this.globalChartConfig = { ...this.globalChartConfig, ...JSON.parse(rawCfg) };
      }
    } catch (e) {}

    this.initWebSocket();
    this.loadSavedState();

    this.storylineInterval = setInterval(() => {
      const activeSym = this.windows[0]?.symbol || "XAUUSD";
      this.fetchStorylineAnalysis(activeSym);
    }, 5000);
  }

  initWebSocket() {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws/chart-stream`;
    this.ws = new WebSocket(wsUrl);

    this.ws.onopen = () => {
      console.log("[WS] Multi-Window Stream Connected");
    };

    this.ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "MARKET_DATA_STREAM" && data.ticks) {
          this.updateDataSourceStatus(data.source, data.is_demo_data);
          this.windows.forEach(win => {
            const symTick = data.ticks[win.symbol];
            if (symTick) {
              win.handleTick(symTick);
            }
          });
        }
      } catch (e) {
        console.error("WS Tick Error:", e);
      }
    };

    this.ws.onclose = () => {
      console.log("[WS] Disconnected, reconnecting in 2s...");
      setTimeout(() => this.initWebSocket(), 2000);
    };
  }

  updateDataSourceStatus(source, isDemo) {
    const pill = document.getElementById("status-pill");
    if (!pill) return;

    if (isDemo || source === "DEMO_DATA") {
      pill.innerHTML = `<span class="pulse-dot"></span> DEMO DATA`;
      pill.className = "status-pill sim";
    } else {
      pill.innerHTML = `<span class="pulse-dot"></span> MT5 LIVE`;
      pill.className = "status-pill";
    }
  }

  async fetchStorylineAnalysis(symbol) {
    try {
      const res = await fetch(`/api/storyline/analysis?symbol=${symbol}`);
      if (!res.ok) return;
      const data = await res.json();
      this.renderCockpitData(data);
    } catch (e) {}
  }

  renderCockpitData(data) {
    if (!data) return;

    // 1. Mobile Slim Widget (v10.2 CR PRO)
    if (data.v10) {
      const v = data.v10;
      
      const elHLeft = document.getElementById("v10-header-left");
      const elHRight = document.getElementById("v10-header-right");
      if (elHLeft) elHLeft.innerHTML = `👑 CR PRO • M30 [${v.m30_in_h4 || 1}/8]`;
      if (elHRight) {
        elHRight.innerHTML = `${v.score}% ${v.conf_tier}`;
        elHRight.className = 'v10-cell right';
        if (v.score >= 80) elHRight.className += ' bg-premium';
        else if (v.score >= 60) elHRight.className += ' bg-strong';
      }

      const applyCell = (id, tf, bias, tag) => {
        const el = document.getElementById(id);
        if (!el) return;
        let colorClass = 'c-wait';
        if (bias === 'BUY') colorClass = 'c-buy';
        if (bias === 'SELL') colorClass = 'c-sell';
        el.innerHTML = `${tf}: <span class="${colorClass}">${bias}</span> [${tag}]`;
      };

      applyCell("v10-d1", "D1", v.d1_bias, v.d1_tag);
      applyCell("v10-h4", "H4", v.h4_bias, v.h4_tag);
      applyCell("v10-h1", "H1", v.h1_bias, v.h1_tag);
      applyCell("v10-m30", "M30", v.m30_bias, v.m30_tag);
      applyCell("v10-m15", "M15", v.m15_bias, v.m15_tag);
      applyCell("v10-m5", "M5", v.m5_bias, v.m5_tag);

      const elRegime = document.getElementById("v10-regime");
      const elEngine = document.getElementById("v10-engine");
      if (elRegime) elRegime.innerHTML = v.regime;
      if (elEngine) elEngine.innerHTML = v.eng_name;

      const elBadge = document.getElementById("v10-action-badge");
      const elPlan = document.getElementById("v10-action-plan");
      const actionRow = document.querySelector(".action-row");
      if (elBadge) {
        elBadge.innerHTML = v.act_badge;
        elBadge.className = 'v10-cell left ' + (v.act_badge.includes('BUY') ? 'c-buy' : (v.act_badge.includes('WAIT') ? 'c-wait' : 'c-sell'));
      }
      if (elPlan) elPlan.innerHTML = v.act_plan;
      if (actionRow) {
        actionRow.style.background = v.act_badge.includes('BUY') ? '#083c20' : (v.act_badge.includes('WAIT') ? '#28200e' : '#441014');
      }
    }

    // 2. Target Barrier & Trade Plan
    const plan = data.trade_plan;
    if (plan) {
      const entryEl = document.getElementById("plan-entry");
      const slEl = document.getElementById("plan-sl");
      const tp1El = document.getElementById("plan-tp1");
      const tp2El = document.getElementById("plan-tp2");

      if (entryEl) entryEl.textContent = Number(plan.entry || 0).toFixed(2);
      if (slEl) slEl.textContent = `${Number(plan.sl || 0).toFixed(2)} (${plan.sl_pips || 30}p)`;
      if (tp1El) tp1El.textContent = `${Number(plan.tp1 || 0).toFixed(2)} (${plan.tp1_pips || 20}p)`;
      if (tp2El) tp2El.textContent = Number(plan.tp2 || 0).toFixed(2);
    }

    // 3. Liquidity Depth Ladder (Bookmap)
    const ladderContainer = document.getElementById("ladder-container");
    if (ladderContainer && data.liquidity && data.liquidity.wall_ladder) {
      ladderContainer.innerHTML = "";
      const ladder = data.liquidity.wall_ladder;
      const maxLots = Math.max(...ladder.map(l => l.lots || 0), 1);

      ladder.forEach(level => {
        const row = document.createElement("div");
        const typeClass = (level.type || "ASK").toUpperCase();
        row.className = `ladder-row ${typeClass}`;
        const fillPct = Math.min(100, Math.round(((level.lots || 0) / maxLots) * 100));

        if (typeClass === "CMP") {
          row.innerHTML = `
            <span>CMP</span>
            <span>${Number(level.price || 0).toFixed(2)}</span>
          `;
        } else {
          row.innerHTML = `
            <div class="ladder-bar" style="width: ${fillPct}%"></div>
            <span>${Number(level.price || 0).toFixed(2)}</span>
            <span>${level.lots}L</span>
          `;
        }
        ladderContainer.appendChild(row);
      });
    }
  }


  setLayout(layoutName) {
    this.layout = layoutName;
    this.applyLayout();
  }

  applyLayout() {
    this.container.className = `chart-grid-container layout-${this.layout.toLowerCase()}`;
    let requiredCount = 4;
    if (this.layout === "SINGLE") requiredCount = 1;
    else if (this.layout === "DUAL_HORIZ" || this.layout === "DUAL_VERT") requiredCount = 2;

    const defaultConfigs = [
      { symbol: "XAUUSD", timeframe: "H4" },
      { symbol: "XAUUSD", timeframe: "M30" },
      { symbol: "XAUUSD", timeframe: "M15" },
      { symbol: "XAUUSD", timeframe: "M5" }
    ];

    while (this.windows.length < requiredCount) {
      const idx = this.windows.length;
      const conf = (this.savedConfigs && this.savedConfigs[idx]) || defaultConfigs[idx] || { symbol: "XAUUSD", timeframe: "M5" };
      const win = new ChartWindow(this, idx + 1, conf);
      this.windows.push(win);
      this.container.appendChild(win.el);
    }

    while (this.windows.length > requiredCount) {
      const win = this.windows.pop();
      win.destroy();
    }

    setTimeout(() => {
      this.windows.forEach(w => w.resize());
    }, 50);

    this.updateActiveLayoutButtons();
    this.saveState();
  }

  toggleMaximizeWindow(win) {
    if (this.maximizedWindow === win) {
      this.maximizedWindow = null;
      this.container.querySelectorAll(".chart-window").forEach(el => el.classList.remove("maximized", "hidden"));
    } else {
      this.maximizedWindow = win;
      this.windows.forEach(w => {
        if (w === win) {
          w.el.classList.add("maximized");
          w.el.classList.remove("hidden");
        } else {
          w.el.classList.remove("maximized");
          w.el.classList.add("hidden");
        }
      });
    }
    setTimeout(() => {
      win.resize();
    }, 50);
  }

  broadcastCrosshair(sourceWinId, timestamp, price) {
    if (!this.isCrosshairLinked) return;
    this.windows.forEach(w => {
      if (w.id !== sourceWinId) {
        w.syncCrosshairTimestamp(timestamp);
      }
    });
  }

  setCrosshairLinked(linked) {
    this.isCrosshairLinked = linked;
    const btn = document.getElementById("btn-link-crosshair");
    if (btn) {
      btn.classList.toggle("active", linked);
      btn.innerHTML = linked ? "🔗 LINK CROSSHAIR: ON" : "⛓ LINK CROSSHAIR: OFF";
    }
    this.saveState();
  }

  setGlobalTool(toolName) {
    this.activeTool = toolName;
    this.windows.forEach(w => {
      if (w.drawingEngine) {
        w.drawingEngine.setTool(toolName);
      }
    });
  }

  updateActiveLayoutButtons() {
    document.querySelectorAll(".layout-btn[data-layout]").forEach(btn => {
      btn.classList.toggle("active", btn.dataset.layout === this.layout);
    });
  }

  saveState() {
    try {
      const winConfigs = this.windows.map(w => w.getStateObject());
      const stateObj = {
        layout: this.layout,
        isCrosshairLinked: this.isCrosshairLinked,
        windows: winConfigs
      };
      localStorage.setItem("cd_window_manager_state_v1", JSON.stringify(stateObj));
    } catch (e) {
      console.warn("Failed to save WindowManager state:", e);
    }
  }

  loadSavedState() {
    try {
      const raw = localStorage.getItem("cd_window_manager_state_v1");
      if (raw) {
        const parsed = JSON.parse(raw);
        this.hasSavedState = true;
        this.layout = parsed.layout || "QUAD";
        this.isCrosshairLinked = parsed.isCrosshairLinked || false;
        this.setCrosshairLinked(this.isCrosshairLinked);

        this.savedConfigs = parsed.windows || null;
        this.applyLayout();
        return;
      }
    } catch (e) {
      console.warn("Failed to load WindowManager state:", e);
    }

    this.hasSavedState = false;
    this.setLayout("QUAD");
  }

  applyGlobalChartConfig(cfg) {
    this.globalChartConfig = { ...this.globalChartConfig, ...cfg };
    this.windows.forEach(w => w.applyChartSettings(this.globalChartConfig));
    try {
      localStorage.setItem("cd_chart_settings_v1", JSON.stringify(this.globalChartConfig));
    } catch (e) {}
    if (window.showToast) window.showToast("⚙ Chart Settings Applied & Saved");
  }
}
