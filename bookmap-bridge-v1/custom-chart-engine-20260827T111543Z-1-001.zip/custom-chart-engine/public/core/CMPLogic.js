/**
 * COMMANDER DADANG — CHAIN REACTION ENGINE PRO
 * CMP Logic (Current Market Profile / Minor SnR Breakout)
 */

export class CMPLogic {
  /**
   * Translates the f_get_data() from Pine Script to Javascript.
   * Calculates Minor Support, Minor Resistance, and the breakout logic for CMP.
   * 
   * @param {Array} candles - Array of OHLC objects {time, open, high, low, close} ordered chronologically.
   * @returns {Object} { arah: "BUY"|"SELL"|"WAIT", cmpLvl: number, barrierLvl: number }
   */
  static calculateCMP(candles) {
    let sup1 = null;
    let res1 = null;
    let arah = "WAIT";
    let cmpLvl = null;
    let lastCmpBuy = null;
    let lastCmpSell = null;
    let barrierLvl = null;

    if (!candles || candles.length < 2) {
      return { arah, cmpLvl, barrierLvl };
    }

    // Start from the second candle since we need previous candle data (close[1], open[1])
    for (let i = 1; i < candles.length; i++) {
      const prev = candles[i - 1];
      const curr = candles[i];

      // Pine: isMinorSup = close[1] < open[1] and close > open
      const isMinorSup = prev.close < prev.open && curr.close > curr.open;
      // Pine: isMinorRes = close[1] > open[1] and close < open
      const isMinorRes = prev.close > prev.open && curr.close < curr.open;

      if (isMinorSup) {
        sup1 = Math.min(prev.close, prev.open);
      }
      if (isMinorRes) {
        res1 = Math.max(prev.close, prev.open);
      }

      // We use curr.close for the breakout logic
      const c = curr.close;

      if (arah === "WAIT") {
        if (res1 !== null && c > res1) {
          arah = "BUY";
          cmpLvl = res1;
          lastCmpBuy = res1;
        } else if (sup1 !== null && c < sup1) {
          arah = "SELL";
          cmpLvl = sup1;
          lastCmpSell = sup1;
        }
      } else if (arah === "BUY") {
        if (sup1 !== null && c < sup1) {
          arah = "SELL";
          barrierLvl = lastCmpBuy; // Tembok Pertama SELL = CMP BUY Lama!
          lastCmpSell = sup1;
          cmpLvl = sup1;
        } else if (res1 !== null && c > res1) {
          lastCmpBuy = res1;
          cmpLvl = res1;
        }
      } else if (arah === "SELL") {
        if (res1 !== null && c > res1) {
          arah = "BUY";
          barrierLvl = lastCmpSell; // Tembok Pertama BUY = CMP SELL Lama!
          lastCmpBuy = res1;
          cmpLvl = res1;
        } else if (sup1 !== null && c < sup1) {
          lastCmpSell = sup1;
          cmpLvl = sup1;
        }
      }
    }

    return { arah, cmpLvl, barrierLvl };
  }
}
