@echo off
title CHAIN REACTION PRO - LIGHTWEIGHT CHART ENGINE
color 0B

echo ===============================================================================
echo     CHAIN REACTION PRO - CUSTOM LIGHTWEIGHT CHARTS (MT5 + STORYLINE)
echo ===============================================================================
echo.
echo [1/3] Menyiapkan environment Python...
cd /d "%~dp0"

echo [2/3] Membuka Custom Chart di Browser (http://localhost:8800)...
start http://localhost:8800

echo [3/3] Menjalankan Backend Chart Server di port 8800...
echo.
python server.py

pause
